﻿namespace InvoiceSystem.Models.DTO
{
    public class SubscriptionReqDTOcs
    {
        public int CustomerId { get; set; }
        public int PlanId { get; set; }
    }
}
